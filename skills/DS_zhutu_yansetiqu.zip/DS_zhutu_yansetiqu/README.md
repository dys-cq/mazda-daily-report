# DS_zhutu_yansetiqu - 产品主图颜色提取技能

从产品图片中提取配色方案，支持多种图片输入方式。

## 📁 目录结构

```
DS_zhutu_yansetiqu/
├── skill.json              # 技能主配置文件
├── requirements.txt        # Python 依赖
├── .env                    # API Key 配置（技能根目录）
├── scripts/
│   └── kieai_uploader.py   # KieAI 图床上传模块
└── README.md               # 本文档
```

## 🚀 功能特性

- ✅ 支持本地文件路径自动转 Base64 上传
- ✅ 支持 Base64 编码数据直接上传
- ✅ 支持 HTTP/HTTPS URL 上传
- ✅ 自动检测输入类型
- ✅ 调用扣子工作流提取颜色
- ✅ API Key 集中管理（.env 文件）

## 📖 使用方法

### 调用方式

**方式 1：本地文件路径**
```
调用 DS_zhutu_yansetiqu，Product_photo_zhu = C:\path\to\image.jpg
```

**方式 2：Base64 编码**
```
调用 DS_zhutu_yansetiqu，Product_photo_zhu = data:image/jpeg;base64,/9j/4AAQSkZJRg...
```

**方式 3：URL**
```
调用 DS_zhutu_yansetiqu，Product_photo_zhu = https://example.com/image.jpg
```

### 输出格式

```json
{
  "success": true,
  "input_type": "local_file",
  "uploaded_image_url": "https://tempfile.redpandaai.co/...",
  "colours": "主背景色 (Main Background): #F4F8F5\n辅色 A: #D6E2DB\n...",
  "note": "文件将在 3 天后自动删除，请及时保存颜色数据"
}
```

## 🔧 配置说明

### API Key 配置

在技能根目录的 `.env` 文件中配置：

```env
# KieAI File Upload API
KIEAI_API_KEY=your_api_key_here

# Coze Workflow API
COZE_API_KEY=your_coze_token_here
COZE_WORKFLOW_ID=your_workflow_id_here
```

**文件位置：** `C:\Users\Administrator\.openclaw\workspace\skills\DS_zhutu_yansetiqu\.env`

**获取方式：**
- **KieAI API Key**: https://kie.ai/api-key
- **Coze API Key**: https://www.coze.cn/open/oauth/pats
- **Coze Workflow ID**: 从扣子工作流 URL 中获取（如 `workflow_id=7619645484659343402`）

### 依赖安装

```bash
cd C:\Users\Administrator\.openclaw\workspace\skills\DS_zhutu_yansetiqu
uv pip install -r requirements.txt
```

## 📦 模块说明

### kieai_uploader.py

提供 KieAI 图床上传功能：

- `upload_to_kieai_base64()` - Base64 上传
- `upload_to_kieai_url()` - URL 上传
- `get_file_url()` - 从上传结果提取文件 URL

## ⚠️ 注意事项

1. **文件存储期限** - KieAI 文件只保存 **3 天**
2. **文件大小** - Base64 上传推荐 ≤10MB
3. **API Key 安全** - 请勿将 `.env` 文件提交到版本控制

## 📝 版本历史

- **v3.0.0** - 重构为模块化架构，API Key 分离管理
- **v2.1.0** - 修复 KieAI downloadUrl 字段处理
- **v2.0.0** - 支持本地文件和 Base64 上传
- **v1.0.0** - 初始版本

## 📞 支持

如有问题，请检查工作日志或联系管理员。
