"""
KieAI 图床上传模块
支持 Base64 上传和 URL 上传两种方式
"""

import requests
import os
from pathlib import Path
from dotenv import load_dotenv

# 获取技能根目录（scripts 的父目录）
skill_root = Path(__file__).parent.parent

# 加载技能根目录下的.env 文件
env_path = skill_root / '.env'
load_dotenv(dotenv_path=env_path)

# 从环境变量读取 API Key
KIEAI_API_KEY = os.getenv('KIEAI_API_KEY')
KIEAI_BASE_URL = 'https://kieai.redpandaai.co'


def upload_to_kieai_base64(base64_data, file_name, upload_path='images/product'):
    """
    使用 Base64 API 上传图片到 KieAI
    
    Args:
        base64_data: Base64 编码的图片数据（包含 data:image/...前缀）
        file_name: 文件名
        upload_path: 上传路径
    
    Returns:
        dict: 上传结果，包含 success 状态和文件信息
    """
    if not KIEAI_API_KEY:
        return {
            'success': False,
            'error': 'KIEAI_API_KEY 未配置，请检查.env 文件'
        }
    
    url = f'{KIEAI_BASE_URL}/api/file-base64-upload'
    headers = {
        'Authorization': f'Bearer {KIEAI_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    payload = {
        'base64Data': base64_data,
        'uploadPath': upload_path,
        'fileName': file_name
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        result = response.json()
        return result
    except Exception as e:
        return {
            'success': False,
            'error': f'上传失败：{str(e)}'
        }


def upload_to_kieai_url(image_url, file_name, upload_path='images/product'):
    """
    使用 URL API 上传图片到 KieAI
    
    Args:
        image_url: 图片的 HTTP/HTTPS URL
        file_name: 文件名
        upload_path: 上传路径
    
    Returns:
        dict: 上传结果，包含 success 状态和文件信息
    """
    if not KIEAI_API_KEY:
        return {
            'success': False,
            'error': 'KIEAI_API_KEY 未配置，请检查.env 文件'
        }
    
    url = f'{KIEAI_BASE_URL}/api/file-url-upload'
    headers = {
        'Authorization': f'Bearer {KIEAI_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    payload = {
        'fileUrl': image_url,
        'uploadPath': upload_path,
        'fileName': file_name
    }
    
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        result = response.json()
        return result
    except Exception as e:
        return {
            'success': False,
            'error': f'上传失败：{str(e)}'
        }


def get_file_url(upload_result):
    """
    从上传结果中提取文件 URL
    
    Args:
        upload_result: KieAI 上传返回的结果
    
    Returns:
        str: 文件 URL，如果失败则返回 None
    """
    if not upload_result.get('success'):
        return None
    
    data = upload_result.get('data', {})
    # 优先使用 downloadUrl，其次使用 fileUrl
    download_url = data.get('downloadUrl', '')
    file_url = data.get('fileUrl', download_url)
    
    return file_url if file_url else download_url


if __name__ == '__main__':
    # 测试代码
    print("KieAI 上传模块 - 测试")
    print(f"API Key 配置：{'已配置' if KIEAI_API_KEY else '未配置'}")
